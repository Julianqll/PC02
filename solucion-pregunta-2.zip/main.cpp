#include <iostream>
#include <vector>
#include "demo.h"
using namespace std;

int main()
{
  vector<TX> v1;
  demoLinkedListSorted();
  cout << "Finalizando el programa ..." << endl;
}



