#ifndef __DOUBLE_LINKED_LIST_H__
#define __DOUBLE_LINKED_LIST_H__
using namespace std;
class DoubleLinkedList
{
    struct NodeDLL
    {
        int data;
        NodeDLL* next;
        NodeDLL* prev;
        NodeDLL(int _data,NodeDLL* _next=nullptr, NodeDLL* _prev=nullptr):data(_data),next(_next),prev(_prev) {}
        int getData()
        {
            return data;
        }
        void setData(int &_data)
        {
            data = _data;
        }
        NodeDLL* getNext()
        {
            return next;
        }
        void setNext(NodeDLL *_next)
        {
            next = _next;
        }
        NodeDLL* getPrev()
        {
            return prev;
        }
        void setPrev(NodeDLL *_prev)
        {
            prev = _prev;
        }
    };

public:
    NodeDLL* head = nullptr;
    NodeDLL* tail = nullptr;
    ~DoubleLinkedList() {}
    void insert(int v)
    {
        NodeDLL* newNode = new NodeDLL(v);
        newNode->setPrev(tail);
        if(tail)
        {
            tail->setNext(newNode);
        }

        if(!head)
        {
            head = newNode;
        }
        tail = newNode;
    }

    void print()
    {
        NodeDLL* temp = head;
        while(temp)
        {
            cout<<temp->getData()<<",";
            temp = temp->getNext();
        }
        cout<<endl;
    }

    bool buscarElemento(int elemento){
      NodeDLL* temp = head;
      while(temp){
        if(temp->getData() == elemento){
          return true;
        }
        temp = temp->getNext();
      }
      return false;
    }

    void eliminarRepetidos(){
      DoubleLinkedList noRepetidos;
      NodeDLL* temp = head;
      while(temp){
        int elemento = temp->getData();
        if(noRepetidos.buscarElemento(elemento)){

          NodeDLL* previous = temp->getPrev();
          NodeDLL* nextNode = temp->getNext();
          if(previous){
            previous->setNext(nextNode);
          }

          if(nextNode){
            nextNode->setPrev(previous);
          }
          delete(temp);
          temp = nextNode;
        }else{
          noRepetidos.insert(elemento);
          temp = temp->getNext();
        }
      }
    }
};


#endif // __DOUBLE_LINKED_LIST_H__
