#include <iostream>
#include "double_linked_list.h"
using namespace std;

int main()
{
    int ar[8] = { 9, 6, 7, 1, 9, 4, 1, 2};
    DoubleLinkedList dll;
    for(int i = 0; i<8; i++)
    {
       for(int j =0 ; j<3; j++)
        dll.insert(ar[i]);
    }
    dll.print();
    dll.eliminarRepetidos();
    dll.print();
    return 0;
}
