#include <iostream>
#include "double_linked_list.h"
using namespace std;



int main()
{
    DoubleLinkedList dll;
    int ar[5] = { 9,2,3,1,4};
    for(int i = 0; i<5; i++)
    {
        dll.insertOrdenado(ar[i]);
        cout<<ar[i]<<endl;
    }
    dll.print();

    cout<<"Ingrese un elemento para buscar en la lista: ";
    int elem;
    cin>>elem;
    int posicion = dll.obtenerPosicion(elem);
    if(posicion != -1){
      cout<<"La posicion del elemento en la lista es: " << posicion<<endl; 
    }else{
      cout<<"No se encontro el elemento en la lista."<<endl;
    }

    DoubleLinkedList invertida = invertirLista(dll);
    cout<<"Lista invertida"<<endl;
    invertida.print();
    int posi = invertida.obtenerPosicion(elem);
    if(posi != -1){
      cout<<"La posicion del elemento en la lista invertida es: " << posi<<endl; 
    }else{
      cout<<"No se encontro el elemento en la lista invertida."<<endl;
    }



    return 0;
}