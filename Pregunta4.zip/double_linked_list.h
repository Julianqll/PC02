#ifndef __DOUBLE_LINKED_LIST_H__
#define __DOUBLE_LINKED_LIST_H__
using namespace std;
class DoubleLinkedList
{
    struct NodeDLL
    {
        int data;
        NodeDLL* next;
        NodeDLL* prev;
        NodeDLL(int _data,NodeDLL* _next=nullptr, NodeDLL* _prev=nullptr):data(_data),next(_next),prev(_prev) {}
        int getData()
        {
            return data;
        }
        void setData(int &_data)
        {
            data = _data;
        }
        NodeDLL* getNext()
        {
            return next;
        }
        void setNext(NodeDLL *_next)
        {
            next = _next;
        }
        NodeDLL* getPrev()
        {
            return prev;
        }
        void setPrev(NodeDLL *_prev)
        {
            prev = _prev;
        }
    };

public:
    NodeDLL* head = nullptr;
    NodeDLL* tail = nullptr;
    int size = 0;
    ~DoubleLinkedList() {}
    void insert(int v)
    {
        NodeDLL* newNode = new NodeDLL(v);
        newNode->setPrev(tail);
        if(tail)
        {
            tail->setNext(newNode);
        }

        if(!head)
        {
            head = newNode;
        }
        tail = newNode;
        size++;
    }

    void print()
    {
        NodeDLL* temp = head;
        while(temp)
        {
            cout<<temp->getData()<<",";
            temp = temp->getNext();
        }
        cout<<endl;
    }

    void insertOrdenado(int v)
    {
        NodeDLL* newNode = new NodeDLL(v);
        if(head)
        {
            NodeDLL* current = head;
            NodeDLL* previous = nullptr;
            while(current && current->getData() < v)
            {
                previous = current;
                current = current->getNext();
            }

            newNode->setPrev(previous);
            newNode->setNext(current);
            if(previous)
            {
                previous->setNext(newNode);
            }
            if(current)
            {
                current->setPrev(newNode);
            }
        }

        if(!newNode->getPrev())
        {
            head = newNode;
        }

        if(!newNode->getNext())
        {
            tail = newNode;
        }
    }

    int obtenerPosicion(int elemento){
      NodeDLL* temp = head;
      int i = 0;
      while(temp){
        if(temp->getData() == elemento){
          return i;
        }
        temp = temp->getNext();
        i++;
      }
      return -1;
    }
};

static DoubleLinkedList invertirLista(DoubleLinkedList dll){
  DoubleLinkedList result; 
  auto temp = dll.tail;
  while(temp){
    result.insert(temp->getData());
    temp  = temp->getPrev();
  }
  return result;
}





#endif // __DOUBLE_LINKED_LIST_H__
