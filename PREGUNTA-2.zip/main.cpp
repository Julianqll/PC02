#include <iostream>
#include <vector>

#include "type.h"
#include "linkedlist.h"
#include "operators.h"
#include "operacion.h"

using namespace std;

const int nElem = 20;
TX vect[nElem] = {5,30,40, 7,80, 90, 13,25, 54,47, 
                    3, 6, 12, 8, 25, 27, 19, 83, 9, 17};


void fx(TX &x)
{  cout << x << ", "; }


template <typename Container, typename F>
void recorrer(Container &container, F ope)
{
  typename Container::iterator iter = container.begin();
  for(; iter != container.end() ; ++iter)
      ope(*iter);
}


template <typename Container>
void recorrer(Container &container)
{
    recorrer(container, fx);  cout << endl;   
}

void insert_element()
{
  TX x= 23;
  linkedlist<TX> mylist;  
  for(auto x=0; x<nElem; x++)
  {  
      mylist.insert_2(vect[x]);      
  }  

  recorrer(mylist, fx);  cout << endl;
  mylist.insert_2(x);
  cout << "El elemento insertado es: " << x << endl ;
  cout << "Nueva Lista: " << endl;
  recorrer(mylist, fx); cout << endl;
}

int main()
{  
  insert_element();
  cout << "Finalizando el programa ..." << endl;  
}
