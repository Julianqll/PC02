#ifndef __TYPES_H__
#define __TYPES_H__

using T1=int;
using TX=long;
#endif