#ifndef __DOUBLE_LINKED_LIST_H__
#define __DOUBLE_LINKED_LIST_H__
using namespace std;
class DoubleLinkedList
{
    struct NodeDLL
    {
        int data;
        NodeDLL* next;
        NodeDLL* prev;
        NodeDLL(int _data,NodeDLL* _next=nullptr, NodeDLL* _prev=nullptr):data(_data),next(_next),prev(_prev) {}
        int getData()
        {
            return data;
        }
        void setData(int &_data)
        {
            data = _data;
        }
        NodeDLL* getNext()
        {
            return next;
        }
        void setNext(NodeDLL *_next)
        {
            next = _next;
        }
        NodeDLL* getPrev()
        {
            return prev;
        }
        void setPrev(NodeDLL *_prev)
        {
            prev = _prev;
        }
    };

public:
    NodeDLL* head = nullptr;
    NodeDLL* tail = nullptr;
    ~DoubleLinkedList() {}
    void insert(int v)
    {
        NodeDLL* newNode = new NodeDLL(v);
        newNode->setPrev(tail);
        if(tail)
        {
            tail->setNext(newNode);
        }

        if(!head)
        {
            head = newNode;
        }
        tail = newNode;
    }

    void print()
    {
        NodeDLL* temp = head;
        while(temp)
        {
            cout<<temp->getData()<<",";
            temp = temp->getNext();
        }
        cout<<endl;
    }

    void insertOrdenado(int v)
    {
        NodeDLL* newNode = new NodeDLL(v);
        if(head)
        {
            NodeDLL* current = head;
            NodeDLL* previous = nullptr;
            while(current && current->getData() < v)
            {
                previous = current;
                current = current->getNext();
            }

            newNode->setPrev(previous);
            newNode->setNext(current);
            if(previous)
            {
                previous->setNext(newNode);
            }
            if(current)
            {
                current->setPrev(newNode);
            }
        }

        if(!newNode->getPrev())
        {
            head = newNode;
        }

        if(!newNode->getNext())
        {
            tail = newNode;
        }
    }

    void concatenarLista(DoubleLinkedList dll)
    {
        NodeDLL* temp = dll.head;
        while(temp)
        {
            insert(temp->getData());
            temp = temp->getNext();
        }
    }
};

static DoubleLinkedList ordenarParesImpares(DoubleLinkedList dll)
{
    DoubleLinkedList pares;
    DoubleLinkedList impares;
    auto temp = dll.head;
    while(temp)
    {
        if(temp->getData() % 2 == 0)
        {
            pares.insertOrdenado(temp->getData());
        }
        else
        {
            impares.insertOrdenado(temp->getData());
        }
        temp = temp->getNext();
    }

    pares.print();
    impares.print();

    pares.concatenarLista(impares);

    return pares;
}





#endif // __DOUBLE_LINKED_LIST_H__
