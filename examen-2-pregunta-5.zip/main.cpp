#include <iostream>
#include <vector>
#include "demo.h"
using namespace std;

int main()
{
  vector<TX> v1;
  demoDoubleLinkedListSorted();
  cout << "Finalizando el programa ..." << endl;
}