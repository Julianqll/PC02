#ifndef __TYPES_H__
#define __TYPES_H__

using T1=double;
using TX=long;
using NodeLE=int;
#endif