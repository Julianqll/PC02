#ifndef __DEMO_H__  
#define __DEMO_H__ 

#include <iostream>
#include <vector>
#include "type.h"
#include "LinkedList.h"
#include "operators.h"
#include "operacion.h"
#include "util.h"
#include "recorrer.h"

using namespace std;

//cantidad de elementos
const int nElem = 20;

TX vect[nElem] = {2,40,35,20,90,95,80,25,4,10,11,46,0,19,75,56,72,8,3};

void demoSwap()
{
  int x = 5, y = 9;
  cout << "x=" << x << ", y=" << y <<endl;
  swap1(x, y);
  cout << "x=" << x << ", y=" << y <<endl;

  double w = 7.3, z = 14.8;
  cout << "w=" << w << ", z=" << z <<endl;
  swap1(w, z);
  cout << "w=" << w << ", z=" << z <<endl;
}

void demoLinkedList()
{
  vect[10] = 53;
  int z=5;
  LinkedList<TX> mylist;
  for(auto x=0; x<10; x++)
  {   mylist.insert_at_tail(vect[x]);
      cout << mylist<<" . "<<endl;
  }
  cout << endl;
  for(auto x=10; x< nElem; x++)
  {   mylist.insert_at_head(vect[x]);
      cout << mylist <<endl;
  }
  auto x1 = mylist[7];
  mylist[5] = 14;
  cout << endl;
  recorrer(mylist);
}

void demoLinkedListSorted(){
  LinkedList<TX> mylist;
  
  cout<< "Primer elemento seleccionado: "<< vect[5] <<endl; 
  cout<< "Segundo elemento seleccionado: "<< vect[6]<<endl; 
  
  for(auto x=0; x<15; x++)
  {   
    cout << "<" << vect[x] <<endl;
    //insertar
    mylist.insert_2(vect[x]);
    recorrer(mylist, fx);  cout << endl;
  }
  
}

#endif