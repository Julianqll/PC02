#include <iostream>
#include <vector>

#include "type.h"
#include "doublelinkedlist.h"
#include "operators.h"
#include "operacion.h"

using namespace std;

const int nElem = 20;
TX vect[nElem] = {5,30,40, 7,80, 90, 23,25, 54,47, 
                    3, 6, 12, 8, 26, 27, 19, 83, 9, 17};

void fx(TX &x)
{  cout << x << "  "; }

void inc(TX &x)
{  ++x; }


template <typename Container, typename F>
void recorrer(Container &container, F ope)
{
  typename Container::iterator iter = container.begin();
  for(; iter != container.end() ; ++iter)
      ope(*iter);
}
template <typename Container>
void recorrer(Container &container)
{
    recorrer(container, fx);  cout << endl;
}

void find_element ()
{
  TX x = 60;  // Elemento que se bucará..
  DoubleLinkedList<TX> mylist;
  for(auto x=0; x<nElem; x++)
  {   
      mylist.insert_2(vect[x]);      
  }
  recorrer(mylist, fx);  cout << endl;
  cout << "Elemento a encontrar: " << x << endl;

  bool condition;  //Busqueda de elemento
  condition = false;
  TX y = 0; 
  while (condition == false && y<nElem){
      if (mylist[y] == x)
      { condition = true; }
      y++;
  }

  if (condition == true){
    cout << "Se encontró el elemento!" << endl;
  }else {
    cout << "No se encontró el elemento :( " << endl;
  }
}

int main()
{
  cout << "Lista: " << endl;
  find_element();
  cout << "Finalizando el programa ..." << endl;
  
}