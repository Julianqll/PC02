#include <iostream>
#include "double_linked_list.h"
using namespace std;


int main()
{
    DoubleLinkedList dll;
    int ar[5] = { 9,2,3,1,4};
    for(int i = 0; i<5; i++)
    {
        dll.insert(ar[i]);
        cout<<ar[i]<<endl;
    }
    dll.print();

    cout<<"Ingrese un elemento para buscar en la lista: ";
    int elem;
    cin>>elem;
    int posicion = dll.buscarElemento(elem);
    if(posicion){
      cout<<"Se encontro el elemento en la lista."<<endl; 
    }else{
      cout<<"No se encontro el elemento en la lista."<<endl;
    }

    return 0;
}